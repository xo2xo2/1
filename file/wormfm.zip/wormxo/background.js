chrome.runtime.onInstalled.addListener(() => {
  console.log("Worm Stream Installed");
});